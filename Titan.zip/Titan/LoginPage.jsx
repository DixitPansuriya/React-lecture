import React, { useState } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    // Add your login logic here
    console.log('Logging in with:', email, password);
  };
const Buttonstyle={
    backgroundColor:"#dda243",
    border:"none",
    width:"150px",
    height:"40px",
}
  return (
    <Container>
        <br/>
        <br/>
        <br/>

        <h1 className='text-center'>LOGIN FOR THE BEST EXPERIENCE</h1>
      <Row className="justify-content-md-center">
        <Col md={6}>
          
          <Form onSubmit={handleLogin}>
            <Form.Group controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group controlId="formBasicPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </Form.Group>
<br/>
<div className='text-center'>
            <Button style={Buttonstyle}   type="submit" block>
              Login
            </Button>
            </div>
          </Form>
        </Col>
      </Row>
    </Container>
  );
};

export default LoginPage;
