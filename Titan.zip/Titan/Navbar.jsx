import React from 'react'

export default function Navbar() {
  
  return (
    <div>
        <div className='d-flex gap-5 justify-content-center bg-light w-100  ' >
            <a>Men</a>
            <a>Women</a>
            <a>Smart Watches</a>
            <a>Premium watchs</a>
            <a>International Brands</a>
            <a>Gifting</a>
            <a>Sale</a>
            <a>Watch Care</a>
            <a>More</a>
<br/>
<br/>






            

            

        </div>
    </div>
  )
}
