import React, { useState } from 'react'

export default function Footer() {
    const [state, setstate] = useState({
        appstore: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw435df752/images/footer/Group%2015609.png",
        play: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwac46a6ed/images/footer/Group%2015610@2x.png",
        master: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw80575962/images/footer/Icon%20payment-mastercard-alt.svg",
        visa: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw7331dfe9/images/footer/Icon%20simple-visa.svg",
        pal: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwcb6903ec/images/footer/Icon%20payment-paypal.svg",
        ex: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwf004a14c/images/footer/american-express-1.svg",
        club: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwa77efe0d/images/footer/diners-club-logo3-1.svg",
        rupay: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw4aef4129/images/footer/rupay.svg",
        icci: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw0ba79c12/images/footer/icici-1.svg",
        axis: "https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw8b4d086c/images/footer/axis-bank-logo-1.svg"
    })
    const Divstyle = {
        width: "100%",
        height: "300px",
        backgroundColor: "black",
    }
    const pstyle = {
        fontSize: "12px"
    }
    return (
        <div>
            <div style={Divstyle} className='text-white d-flex justify-content-around   '>
                <div>
                    <h6>COLLECTIONS</h6>
                    <p style={pstyle}>Titan Automatics</p>
                    <p style={pstyle}>Police Batman</p>
                    <p style={pstyle}>Stellar</p>
                    <p style={pstyle}>Raga Power Pearls</p>
                    <p style={pstyle}>Nebula Jewels</p>
                    <p style={pstyle}>Grandmaster</p>
                    <p style={pstyle}>Maritime</p>


                </div>
                <div>
                    <h6>CUSTOMER SERVICE</h6>
                    <p style={pstyle}>Payment Options</p>
                    <p style={pstyle}>Track Order</p>
                    <p style={pstyle}>Encircle Program</p>
                    <p style={pstyle}>Find Titan World Stores</p>



                </div>
                <div>
                    <h6>CONTACT US</h6>
                    <p style={pstyle}>1800-266-0123</p>
                    <p style={pstyle}>customercare@titan.co.in</p>
                    <p style={pstyle}>Help & Contact</p>
                    <p style={pstyle}>FAQs</p>



                </div>
                <div>
                    <h6>ABOUT TITAN</h6>
                    <p style={pstyle}>Brand Protection</p>
                    <p style={pstyle}> Corporate</p>
                    <p style={pstyle}>Careers</p>




                </div>
                <div>
                    <h6>Download Titan World App</h6>
                    <div>
                        <img src={state.appstore} alt="" />
                        <img src={state.play} style={{ height: "40px" }} alt="" />

                    </div>
                    <div>
                        <h6>Follow Us With</h6>
                        <div className='d-flex gap-3'>
                            <i style={{ fontSize: "32px" }} class="fab fa-instagram-square"></i>
                            <i style={{ fontSize: "32px" }} class="fab fa-facebook-square"></i>
                            <i style={{ fontSize: "32px" }} class="fab fa-twitter-square"></i>
                            <i style={{ fontSize: "32px" }} class="fab fa-youtube-square"></i>
                        </div>
                        <div>
                            <h4>Want Help <a href="#">Click Here</a> To chat on <i class="fab fa-whatsapp"></i></h4>
                            <p>Operating Hours: 10:00AM To 10:00PM <br /> Monday To Sunday</p>
                        </div>
                    </div>
                </div>
            </div>
            <div >
                <div className='text-white d-flex justify-content-between' style={{ backgroundColor: "black" }}>
                    <div className='d-flex gap-3'>
                        <img src={state.visa} alt="" />
                        <img src={state.pal} alt="" />
                        <img src={state.club} alt="" />
                        <img src={state.rupay} alt="" />
                        <img src={state.master} alt="" />
                        <img src={state.ex} alt="" />
                        <img src={state.axis} alt="" />
                        <img src={state.icci} alt="" />







                    </div>
                    <div className='d-flex gap-2 mt-3'>
                        <h6>© 2023 Titan World. All Rights Reserved</h6>
                        <h6>|</h6>
                        <h6>Terms & Conditions</h6>
                        <h6>|</h6>
                        <h6>Privacy Policy</h6>
                        <h6>|</h6>
                        <p>Wearable Privacy Policy</p>
                    </div>
                </div>
            </div>
        </div>
    )
}
