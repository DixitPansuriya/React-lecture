import React from 'react'

export default function Header() {
    const Divstyle = {
        maxwidth: "100%",
       
    }
    const Inputstyle = {
        width: "883px",
        height: "42px"
    }
    return (
        <div> 
            <div style={Divstyle} className='d-flex justify-content-around mt-3 border-bottom'>
                <div className='logo mt-2 '>
                    <img src='https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwb6d5816b/images/homepage/titan-logo.svg' />
                </div>
                <div className='Search'>
                    <input type='text' placeholder='search' style={Inputstyle} />
                </div>
                <div className='icon d-flex gap-5' >
                    <div className='text-center'>
                        <span class="material-icons">
                            person_outline
                        </span>
                        <p>Account</p>
                    </div>
                    <div className='text-center'>
                        <span class="material-icons">
                            favorite_border
                        </span>
                        <p>Wishlist</p>
                    </div>
                    <div className='text-center'>
                        <span class="material-icons">
                            work_outline
                        </span>
                        <p>Cart</p>
                    </div>
                    <div className='text-center'>
                        <span class="material-icons">
                            view_in_ar
                        </span>
                        <p>Take order</p>
                    </div>
                </div>
            </div>

        </div>
    )
}
