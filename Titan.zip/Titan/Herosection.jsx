import React from 'react'

export default function Herosection() {
  const Imgstyle ={
    width:"100%"
  }
  return (
    <div>
      <div>
        <img  style={Imgstyle }  src='https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwef7f1ea7/images/PLP/MaySale_PLP.jpg' />
      </div>
      <div className='d-flex justify-content-evenly bg-light '>
        <div className='d-flex mt-3'>
          <span class="material-symbols-outlined">
            calendar_month
          </span>
          <p>Book An Appointment</p>
        </div>
        <div className='d-flex mt-3'>
          <span class="material-symbols-outlined">
            percent
          </span>
          <p>Buy With No Cost EMI</p>
        </div>
        <div className='d-flex mt-3'>
          <span class="material-symbols-outlined">
            store
          </span>
          <p>Pickup At The Store</p>
        </div>
      </div>
    </div>
  )
}
