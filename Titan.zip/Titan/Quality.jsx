import React, { useState } from 'react'

export default function Quality() {
    const [state,setstate]=useState({
original:"https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwc17b5cd2/images/homepage/Gurantee.svg",
day:"https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw0987d956/images/homepage/Return.svg",
shipping:"https://www.titan.co.in/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dw824f2669/images/homepage/Shipping.svg"
    })
  return (
    <div>
      <div className='d-flex justify-content-evenly text-center '>
        <div>
<img src={state.original} alt="" />
<h3>100% original</h3>
        </div>
        <div>
<img src={state.day} alt="" />
<h3>7 Day Return</h3>
        </div>
        <div>
<img src={state.shipping} alt="" />
<h3>Free Shipping</h3>
        </div>
      </div>

      
    </div>
  )
}
