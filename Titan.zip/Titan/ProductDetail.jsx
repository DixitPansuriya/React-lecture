import React from 'react'

export default function ProductDetail() {
  
  return (
    <div>ProductDetail</div>
  )
}
