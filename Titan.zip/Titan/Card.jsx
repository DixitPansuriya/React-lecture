import React from 'react';
import data from '../Data/data';

export default function Card() {
  return (
    <div className="container">
      <div className="row  d-flex justify-content-around" style={{ margin: 0, width: '100%' }}>
        {data.map((item, index) => (
          <div className="col-6 col-md-3 mb-4" key={index} style={{ padding: 0 }}>
            <div className="card" style={{ width: '332.5px', height: '332.5px' }}>
              <img src={item.img} className="card-img-top" alt={item.Name} style={{ width: '100%', height: 'auto' }} />
              <div className="card-body">
                <h5 className="card-title">{item.Name}</h5>
                <p className="card-text">{item.Description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
