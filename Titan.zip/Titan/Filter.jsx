import React from 'react'

export default function Filter() {
  return (
    <div>
        <div>
            <h1 className='text-center'>This is filter</h1>
        </div>
    </div>
  )
}
