import React from 'react'

export default function Bestseller() {
    const Divstyle={
        height:'500px',
        width:"800px",
marginLeft:"26%"

    }
  return (
    <div className='text-center' >
        <div >
<div style={Divstyle}  >
<div className='d-flex justify-content-between mt-5 border-bottom '>
  <h4>bestseller</h4>
  <h4>Price(rs)</h4>
</div>
<div>
<div className='d-flex justify-content-between border-bottom '>
  <p>Titan Men's Multifunction Karishma: Two-Tone Steel Elegance Watch</p>
  <p>₹ 3,585</p>
</div>
<div className='d-flex justify-content-between border-bottom '>
  <p>Titan Neo Splash Blue Dial Quartz Multifunction Stainless Steel Strap watch for Men</p>
  <p>₹ 7,995</p>
</div>
<div className='d-flex justify-content-between border-bottom '>
  <p>Titan Women's Lagan Watch: Rose Gold Accents & Refined Elegance </p>
  <p>₹ 2,835</p>
</div>
<div className='d-flex justify-content-between border-bottom '>
  <p>Titan Neo Splash Quartz Multifunction Black Dial Stainless Steel Strap Watch for Men </p>
  <p>₹ 7,345</p>
</div>
<div className='d-flex justify-content-between border-bottom '>
  <p>Raga Women's Charm: Elegant Mother of Pearl Dial with Ornate Strap Watch</p>
  <p>₹ 7,765</p>
</div>
<div className='d-flex justify-content-between border-bottom '>
  <p>Karishma Radiance Champagne Dial Analog Watch for Men</p>
  <p>₹ 2,905</p>
</div>
<div className='d-flex justify-content-between border-bottom '>
  <p>Titan Bandhan Quartz Analog with Date Silver Dial Stainless Steel Strap Watch for Couple</p>
  <p>₹ 2,905</p>
</div>  
<div className='d-flex justify-content-between border-bottom '>
  <p>Titan Workwear Green Dial Analog Leather Strap Watch for Men</p>
  <p>₹ 3,375</p>
</div> 
<div className='d-flex justify-content-between border-bottom '>
  <p>Titan Automatics Blue Dial Automatic Leather Strap watch for Men</p>
  <p>₹ 18,765
</p>
</div>  
</div>
</div>
</div>
    </div>
  )
}
