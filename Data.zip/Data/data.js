const data =[
    {
      id:1,
      img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw3e10e985/images/Titan/Catalog/1713BM02_1.jpg?sw=800&sh=800",
      Name:"Titan Men's Multifunction Karishma: Two-Tone Steel Elegance Watch",
      Price:"₹ 3,585"
    },
    {
      id:2,
      img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw1888ad40/images/Titan/Catalog/1805QM01_1.jpg?sw=800&sh=800",
      Name:"Titan Neo Splash Blue Dial  Stainless Steel Strap watch for Men",
      Price:"₹ 7,995"

    },
    {
      id:3,
      img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw9c842df9/images/Titan/Catalog/1824BM03_1.jpg?sw=800&sh=800",
      Name:"Titan Neo Splash Black Dial Stainless Steel Strap Watch for Men",
      Price:"₹ 7,345"

    },
    {
      id:4,
      img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw0814ec34/images/Titan/Catalog/1805QM04_1.jpg?sw=800&sh=800",
      Name:"Titan Men's Trendsetter Watch: Chic Blue Dial & Two-Tone Strap",
      Price:"₹ 3,995"

    },
    {
        id:5,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw6c9df22a/images/Titan/Catalog/2656WM01_1.jpg?sw=800&sh=800",
        Name:"Titan Women's Lagan Watch: Rose Gold Accents & Refined Elegance",
        Price:"₹ 2,835"
  
      },{
        id:6,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw5487e70b/images/Titan/Catalog/2606WM08_1.jpg?sw=800&sh=800",
        Name:"Raga Women's Charm: Elegant Mother of Pearl Dial with Ornate Strap Watch",
        Price:"₹ 7,765"
  
      },{
        id:7,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw35638a2a/images/Titan/Catalog/95154QM01_1.jpg?sw=800&sh=800",
        Name:"Raga Women's Love all: Elegant Oval Brown Dial & Metal Strap Watch",
        Price:"₹ 11,985."
  
      },{
        id:8,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwe1a94e04/images/Titan/Catalog/1849YM01_1.jpg?sw=800&sh=800",
        Name:"Titan Black and Gold  Date Silver Dial Stainless Steel Strap Watch for Women",
        Price:"₹ 7,445"
  
      },

      {
        id:9,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwd27cc9fc/images/Titan/Catalog/95142QM01_1.jpg?sw=800&sh=800",
        Name:"Titan Slimline Blue Dial Analog Stainless Steel Strap watch for Women",
        Price:"₹ 8,915"
  
      },{
        id:10,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwac5e8c3f/images/Titan/Catalog/2653NC01_1.jpg?sw=800&sh=800",
        Name:"Titan Edge Ceramic Black Dial Analog Ceramic Strap watch for Women",
        Price:"₹ 23,495"
  
      },{
        id:11,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw4d390545/images/Titan/Catalog/9893VM02_1.jpg?sw=800&sh=800",
        Name:"Titan Raga Silver Mother Of Pearl Silver Strap Watch for Women",
        Price:"₹ 36,295"
  
      },{
        id:12,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw8bfefcce/images/Titan/Catalog/95129QM01_1.jpg?sw=800&sh=800",
        Name:"Titan Animalia Brown Dial Analog Stainless Steel Strap watch for Women",
        Price:" ₹ 13,285"
  
      },

      {
        id:13,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw1888ad40/images/Titan/Catalog/1805QM01_1.jpg?sw=800&sh=800",
        Name:"Titan Neo Splash Blue Dial Quartz Multifunction Stainless best watch Steel Strap watch for Men",
        Price:"₹ 7,995"
  
      },{
        id:14,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw758a93e3/images/Titan/Catalog/1806NL02_1.jpg?sw=800&sh=800",
        Name:"Titan Men's Timeless Style Watch best watch time maniupulation: Refined Gold Dial and Leather Strap",
        Price:" ₹ 3,995"
  
      },{
        id:15,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw06e4f29b/images/Titan/Catalog/90175KD01_1.jpg?sw=800&sh=800",
        Name:"Titan Ceramic Fusion Skeleton Automatic Rich Black Dial Steel & Ceramic Strap Watch For Men",
        Price:"₹ 25,495"
  
      },{
        id:16,
        img:"https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw78b518bc/images/Titan/Catalog/5015DL06_1.jpg?sw=800&sh=800",
        Name:"Titan Nebula Calligraphy best watch time  Quartz Analog 18 Karat Solid Gold Watch for Men",
        Price:" ₹ 217,750"
  
      },
  ]
export default data